# BizFlow Platform - Setup & Deployment Guide

## 📋 Project Overview

BizFlow is a white-label SaaS platform designed for Kenyan businesses. It provides:
- Finance management (income, expenses, profit tracking)
- Staff management
- Inventory/Stock control
- Appointments scheduling
- Debt tracking
- Business analytics
- M-Pesa integration ready

## 🏗️ Architecture

### Folder Structure
```
bizflow/
├── index.html                          # Landing page
├── auth/
│   ├── signup.html
│   └── signin.html
├── dashboard/
│   └── select-business.html
├── assets/
│   ├── css/
│   │   ├── global.css                 # Design system & variables
│   │   ├── landing.css
│   │   ├── auth.css
│   │   └── dashboard.css
│   └── js/
│       ├── supabase-client.js         # Supabase integration
│       ├── auth-handler.js            # Authentication logic
│       ├── utils.js                   # Utility functions
│       └── dashboard.js               # Business selection logic
└── README.md
```

## 🎨 Design System

**Colors (Kenyan Modern)**
- Primary: #1f9b57 (Green - Kenya flag)
- Primary Dark: #16754a
- Secondary: #ff6b3d (Orange)
- Gray tones for neutral elements

**Responsive Design**
- Mobile-first approach
- Breakpoint: 768px
- Optimized for slow connections

## 📱 Pages

### 1. Landing Page (index.html)
- Navigation with Sign In / Get Started CTAs
- Hero section with dashboard preview
- Quick features (6 cards)
- Pricing section (3 tiers: 999, 2499, 4999 KES)
- Features section (Kenyan-focused)
- Footer with links

### 2. Sign Up (auth/signup.html)
- Business name input
- Owner name input
- Email input
- Phone (WhatsApp) input
- Password (8+ chars required)
- Terms & conditions checkbox
- Supabase integration for user creation

### 3. Sign In (auth/signin.html)
- Email input
- Password input
- Remember me checkbox
- Forgot password link
- Supabase authentication

### 4. Business Selection (dashboard/select-business.html)
- 12 business categories with emojis
- Grid layout (responsive)
- Click to select business
- Stores selection in localStorage
- Sign out button

## 🔑 Key Features

### Pricing Tiers
- **Starter** (KES 999): Basic finance, 2 staff, simple reports
- **Professional** (KES 2,499): Full suite, unlimited staff, advanced reports
- **Enterprise** (KES 4,999): Everything + multi-location, API, white-label

### Business Categories
1. Restaurant (🍽️)
2. Betting Shop (🎰)
3. Chemist (💊)
4. Bookshop (📚)
5. Salon & Spa (💇)
6. Supermarket (🛒)
7. Hotel (🏨)
8. Gym & Fitness (💪)
9. Clinic (🏥)
10. Tailoring Shop (👔)
11. Garage (🔧)
12. Other Business (🏢)

## ⚙️ Configuration

### Supabase Setup

1. Go to https://supabase.com
2. Create a new project
3. Get your credentials:
   - Project URL
   - Anon Key

4. Update `assets/js/supabase-client.js`:
```javascript
const SUPABASE_CONFIG = {
    url: 'YOUR_SUPABASE_URL',
    anonKey: 'YOUR_SUPABASE_ANON_KEY'
};
```

### Database Schema (Supabase)

Create these tables in Supabase:

**users (auto-created by Supabase Auth)**
- id (UUID)
- email
- created_at

**user_profiles**
- id (UUID, PK)
- user_id (UUID, FK)
- business_name (text)
- owner_name (text)
- phone (text)
- created_at

**user_businesses**
- id (UUID, PK)
- user_id (UUID, FK)
- business_type (text)
- business_name (text)
- selected_at (timestamp)

**finances**
- id (UUID, PK)
- user_id (UUID, FK)
- business_id (UUID, FK)
- type (income/expense)
- amount (numeric)
- description (text)
- date (date)
- created_at

## 🚀 Deployment

### Option 1: GitHub Pages
1. Push all files to GitHub
2. Enable GitHub Pages in settings
3. Set source to main branch
4. Access at: https://username.github.io/bizflow

### Option 2: Netlify
1. Connect GitHub repo to Netlify
2. Deploy automatically on push
3. Set custom domain

### Option 3: Vercel
1. Connect GitHub repo to Vercel
2. Deploy automatically
3. Fast, optimized hosting

## 💻 Development

### Local Testing
```bash
# Open in browser
open index.html

# Or use live server
python -m http.server 8000
# Visit http://localhost:8000
```

### Supabase Integration
- Uses REST API (no SDK needed)
- Session stored in localStorage
- User data persisted in Supabase

## 🔐 Security Considerations

1. **Authentication**: Supabase handles password hashing
2. **RLS (Row Level Security)**: Configure in Supabase
3. **HTTPS**: All production deployments must use HTTPS
4. **Credentials**: Never commit API keys - use environment variables

## 📊 User Flow

1. User lands on index.html (landing page)
2. Clicks "Get Started" → redirected to auth/signup.html
3. Fills form → account created in Supabase
4. Redirected to dashboard/select-business.html
5. Selects business type → stored in localStorage
6. Ready for next phase (business dashboard setup)

## 🎯 Next Steps

After this foundation:
1. Create business-specific dashboards
2. Build finance tracking module
3. Implement staff management
4. Add M-Pesa integration
5. Create analytics/reports section

## 📝 Notes for Kenyan Context

✅ Currency: KES (Kenya Shillings)
✅ Phone: +254 format
✅ Language: English (with Kiswahili support ready)
✅ Payment: M-Pesa integration ready
✅ Time: East Africa Time (EAT, UTC+3)
✅ Business: Tailored for Kenyan small-medium businesses

## 🆘 Troubleshooting

**Issue**: Supabase API errors
- Check URL and anon key are correct
- Verify CORS settings in Supabase

**Issue**: Redirects not working
- Check browser console for errors
- Verify localStorage is not disabled

**Issue**: Styling looks broken on mobile
- Check viewport meta tag in HTML head
- Test with browser dev tools mobile view

---

**Made with ❤️ for Kenya**
